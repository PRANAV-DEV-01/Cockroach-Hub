import { useEffect, useState } from "react";
import { Settings as SettingsIcon, Save, AlertTriangle } from "lucide-react";
import { Button } from "../../components/ui/Button";
import { useLocale } from "../../hooks/useLocale";
import { useAuthStore } from "../../store/authStore";
import api from "../../lib/api";
import toast from "react-hot-toast";
import type { SiteSettings } from "../../types";

export default function AdminSettings() {
  const { t } = useLocale();
  const me = useAuthStore((s) => s.admin);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const fetch = () => {
    setLoading(true);
    api.get("/admin/settings").then(({ data }) => setSettings(data)).catch(() => toast.error(t("common.error"))).finally(() => setLoading(false));
  };
  useEffect(() => { fetch(); }, []);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    try {
      const { data } = await api.put("/admin/settings", {
        site_name: settings.site_name,
        contact_email: settings.contact_email,
        maintenance_mode: settings.maintenance_mode,
        maintenance_message: settings.maintenance_message,
        submissions_open: settings.submissions_open,
      });
      setSettings(data);
      toast.success(t("common.saved"));
    } catch (err: any) {
      toast.error(err.response?.data?.detail || t("common.error"));
    }
    setSaving(false);
  };

  if (loading) return <p className="text-sm text-ph-text-muted">{t("admin.loading")}</p>;
  if (!settings) return null;

  return (
    <div className="space-y-5 max-w-2xl">
      <div className="flex items-center gap-2">
        <SettingsIcon className="h-5 w-5 text-ph-orange" />
        <h1 className="text-xl font-black text-ph-text-dark dark:text-white">{t("admin.settings")}</h1>
      </div>

      {!me?.is_super && (
        <div className="bg-ph-yellow/10 border border-ph-yellow/20 p-4">
          <p className="text-sm text-ph-yellow font-bold">{t("admin.permissionNotice")}</p>
        </div>
      )}

      <form onSubmit={save} className="space-y-4 bg-white dark:bg-ph-dark-2 border border-ph-border-light dark:border-ph-border p-5">
        <div>
          <label className="ph-label">{t("admin.siteName")}</label>
          <input className="ph-input" value={settings.site_name} disabled={!me?.is_super}
            onChange={(e) => setSettings({ ...settings, site_name: e.target.value })} required />
        </div>
        <div>
          <label className="ph-label">{t("admin.contactEmail")}</label>
          <input type="email" className="ph-input" value={settings.contact_email ?? ""} disabled={!me?.is_super}
            onChange={(e) => setSettings({ ...settings, contact_email: e.target.value })} />
        </div>

        <label className="flex items-center gap-3 py-1">
          <input type="checkbox" className="h-4 w-4" checked={settings.submissions_open} disabled={!me?.is_super}
            onChange={(e) => setSettings({ ...settings, submissions_open: e.target.checked })} />
          <span className="text-sm font-bold text-ph-text-dark dark:text-white">{t("admin.submissionsOpen")}</span>
        </label>

        <label className="flex items-center gap-3 py-1">
          <input type="checkbox" className="h-4 w-4" checked={settings.maintenance_mode} disabled={!me?.is_super}
            onChange={(e) => setSettings({ ...settings, maintenance_mode: e.target.checked })} />
          <span className="text-sm font-bold text-ph-text-dark dark:text-white">{t("admin.maintenanceMode")}</span>
        </label>

        {settings.maintenance_mode && (
          <div className="flex items-start gap-2 bg-ph-red/10 border border-ph-red/20 p-3">
            <AlertTriangle className="h-4 w-4 text-ph-red shrink-0 mt-0.5" />
            <p className="text-xs text-ph-red">{t("admin.maintenanceWarning")}</p>
          </div>
        )}

        <div>
          <label className="ph-label">{t("admin.maintenanceMessage")}</label>
          <textarea className="ph-input resize-none" rows={2} disabled={!me?.is_super}
            value={settings.maintenance_message ?? ""}
            onChange={(e) => setSettings({ ...settings, maintenance_message: e.target.value })} />
        </div>

        {me?.is_super && (
          <div className="flex justify-end pt-2">
            <Button type="submit" disabled={saving}><Save className="h-4 w-4" />{saving ? t("admin.saving") : t("admin.saveSettings")}</Button>
          </div>
        )}
      </form>
    </div>
  );
}
