import { useState } from "react";
import { UserCircle, Save, KeyRound } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "../../components/ui/Button";
import { useLocale } from "../../hooks/useLocale";
import { useAuthStore } from "../../store/authStore";
import api from "../../lib/api";
import toast from "react-hot-toast";

export default function AdminAccount() {
  const { t } = useLocale();
  const admin = useAuthStore((s) => s.admin);
  const token = useAuthStore((s) => s.token);
  const setAuth = useAuthStore((s) => s.setAuth);
  const [name, setName] = useState(admin?.name ?? "");
  const [email, setEmail] = useState(admin?.email ?? "");
  const [saving, setSaving] = useState(false);

  if (!admin || !token) return null;

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { data } = await api.patch("/auth/me", { name, email });
      setAuth(token, data);
      toast.success(t("common.saved"));
    } catch (err: any) {
      toast.error(err.response?.data?.detail || t("common.error"));
    }
    setSaving(false);
  };

  return (
    <div className="space-y-5 max-w-md">
      <div className="flex items-center gap-2">
        <UserCircle className="h-5 w-5 text-ph-orange" />
        <h1 className="text-xl font-black text-ph-text-dark dark:text-white">{t("admin.myAccount")}</h1>
      </div>

      <form onSubmit={save} className="space-y-4 bg-white dark:bg-ph-dark-2 border border-ph-border-light dark:border-ph-border p-5">
        <div>
          <label className="ph-label">{t("admin.name")}</label>
          <input className="ph-input" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div>
          <label className="ph-label">{t("admin.usernameOrEmail")}</label>
          <input className="ph-input" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div className="flex justify-end pt-2">
          <Button type="submit" disabled={saving}><Save className="h-4 w-4" />{saving ? t("admin.saving") : t("admin.saveSettings")}</Button>
        </div>
      </form>

      <Link to="/admin/change-password"
        className="flex items-center gap-2 bg-white dark:bg-ph-dark-2 border border-ph-border-light dark:border-ph-border p-4 text-sm font-bold text-ph-text-dark dark:text-white hover:border-ph-orange">
        <KeyRound className="h-4 w-4 text-ph-orange" />{t("admin.changePassword")}
      </Link>
    </div>
  );
}
