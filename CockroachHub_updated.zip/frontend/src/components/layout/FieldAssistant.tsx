import { useState, useRef, useEffect } from "react";
import { Bot, X, Send, Loader } from "lucide-react";
import api from "../../lib/api";
import { useLocale } from "../../hooks/useLocale";

interface ChatMsg { role: "user" | "assistant"; text: string; source?: string }

export function FieldAssistant() {
  const { t } = useLocale();
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, open]);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    const message = input.trim();
    if (!message || busy) return;
    setMsgs((m) => [...m, { role: "user", text: message }]);
    setInput("");
    setBusy(true);
    try {
      const { data } = await api.post("/assistant", { message });
      setMsgs((m) => [...m, { role: "assistant", text: data.reply, source: data.source }]);
    } catch {
      setMsgs((m) => [...m, { role: "assistant", text: t("assistant.error") }]);
    }
    setBusy(false);
  };

  return (
    <>
      <button
        onClick={() => setOpen((v) => !v)}
        className="fixed bottom-20 right-4 md:bottom-6 z-40 flex h-12 w-12 items-center justify-center rounded-full bg-ph-orange text-white shadow-lg hover:bg-ph-orange/90"
        aria-label={t("assistant.open")}
        title={t("assistant.open")}
      >
        {open ? <X className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
      </button>

      {open && (
        <div className="fixed bottom-36 right-4 md:bottom-24 md:right-6 z-40 flex h-[60vh] max-h-[480px] w-[calc(100vw-2rem)] max-w-sm flex-col rounded-md border border-ph-border bg-ph-dark shadow-2xl">
          <div className="flex items-center gap-2 border-b border-ph-border px-4 py-3">
            <Bot className="h-4 w-4 text-ph-orange" />
            <div>
              <p className="text-sm font-bold text-white">{t("assistant.title")}</p>
              <p className="text-[10px] text-ph-text-muted">{t("assistant.subtitle")}</p>
            </div>
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto p-3">
            {msgs.length === 0 && (
              <p className="text-xs text-ph-text-muted">{t("assistant.empty")}</p>
            )}
            {msgs.map((m, i) => (
              <div key={i} className={`text-xs leading-relaxed whitespace-pre-wrap ${m.role === "user" ? "text-right" : "text-left"}`}>
                <span className={`inline-block max-w-[90%] rounded-md px-3 py-2 ${
                  m.role === "user" ? "bg-ph-orange text-white" : "bg-ph-card text-ph-text-secondary"
                }`}>
                  {m.text}
                </span>
              </div>
            ))}
            {busy && <Loader className="h-4 w-4 animate-spin text-ph-text-muted" />}
            <div ref={endRef} />
          </div>

          <form onSubmit={send} className="flex items-center gap-2 border-t border-ph-border p-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={t("assistant.placeholder")}
              className="ph-input flex-1 text-xs"
              maxLength={500}
            />
            <button type="submit" disabled={busy || !input.trim()} className="p-2 text-ph-orange disabled:opacity-40" aria-label={t("assistant.send")}>
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
