"""Local AI assistant.

Design goal: stay consistent with CockroachHub's zero-data-collection, offline-first
ethos. This agent never calls an external/cloud API and needs no API key:

- Primary: talks to a locally-hosted Ollama server (OLLAMA_URL env var, defaults to
  http://localhost:11434) — i.e. a model running on the same machine/network as the
  backend. If that server isn't reachable, nothing is sent anywhere.
- Fallback: a simple keyword search over the site's own public content (legal rights,
  emergency contacts, active alerts) so the assistant still answers useful questions
  with zero dependencies when no local model is installed.
"""

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models import Alert, EmergencyContact, LegalRight

SYSTEM_PROMPT = (
    "You are the CockroachHub Field Assistant, a calm and factual assistant for student "
    "protesters in India. Answer briefly and only using the CONTEXT below. "
    "If the answer isn't in the context, say you don't have that information and point "
    "the person to the Legal Rights or Emergency page. Never invent phone numbers, legal "
    "section numbers, or locations that aren't in the context."
)


async def build_context(db: AsyncSession, message: str, limit: int = 5) -> str:
    """Pull the most relevant public content into a short context block."""
    like = f"%{message[:100]}%"
    parts: list[str] = []

    rights = await db.execute(
        select(LegalRight).where(LegalRight.title.ilike(like) | LegalRight.content.ilike(like)).limit(limit)
    )
    for r in rights.scalars().all():
        parts.append(f"[Legal Right] {r.title}: {r.content[:400]}")

    contacts = await db.execute(
        select(EmergencyContact).where(EmergencyContact.name.ilike(like) | EmergencyContact.category.ilike(like)).limit(limit)
    )
    for c in contacts.scalars().all():
        parts.append(f"[Contact] {c.name} ({c.category}): {c.phone}")

    alerts = await db.execute(
        select(Alert).where(Alert.is_active == True).order_by(Alert.created_at.desc()).limit(3)  # noqa: E712
    )
    for a in alerts.scalars().all():
        parts.append(f"[Active Alert] {a.title} ({a.severity}, {a.location or 'unknown location'}): {a.description[:200]}")

    if not parts:
        # No keyword match — give the model a small general snapshot instead of nothing.
        rights = await db.execute(select(LegalRight).order_by(LegalRight.sort_order).limit(3))
        parts = [f"[Legal Right] {r.title}: {r.content[:300]}" for r in rights.scalars().all()]

    return "\n\n".join(parts) if parts else "No matching content found on the site."


async def query_local_llm(message: str, context: str) -> str | None:
    """Ask a locally-hosted Ollama server. Returns None if unavailable (never raises)."""
    if not settings.ai_agent_enabled:
        return None
    payload = {
        "model": settings.ollama_model,
        "messages": [
            {"role": "system", "content": f"{SYSTEM_PROMPT}\n\nCONTEXT:\n{context}"},
            {"role": "user", "content": message},
        ],
        "stream": False,
    }
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            resp = await client.post(f"{settings.ollama_url.rstrip('/')}/api/chat", json=payload)
            resp.raise_for_status()
            data = resp.json()
            content = (data.get("message") or {}).get("content")
            return content.strip() if content else None
    except Exception:
        return None


def faq_fallback(message: str, context: str) -> str:
    """Zero-dependency fallback used when no local model is reachable."""
    if context and context != "No matching content found on the site.":
        return (
            "Here's the most relevant information I found on the site "
            "(no local AI model is running, so this is a direct content match):\n\n" + context
        )
    return (
        "I couldn't find anything matching that on the site, and no local AI model is "
        "currently running. Try the Legal Rights, Emergency, or Live Feed pages, or set up "
        "a local model (see OLLAMA_URL in backend/.env) for open-ended answers."
    )
